/* eslint-disable @typescript-eslint/no-explicit-any */
'use client'

import { Button } from '@/components/ui/button'
import { Spinner } from '@/components/ui/spinner'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import useCartStore from '@/hooks/use-cart-store'
import { OrderItem } from '@/types'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { toast } from 'sonner'
import { useTranslations } from 'next-intl'

export default function AddToCart({
  item,
  minimal = false,
}: {
  item: OrderItem
  minimal?: boolean
}) {
  const router = useRouter()
  const { addItem } = useCartStore()
  //PROMPT: add quantity state
  const [quantity, setQuantity] = useState(1)
  const [isAddingToCart, setIsAddingToCart] = useState(false)
  const [isBuyingNow, setIsBuyingNow] = useState(false)
  const t = useTranslations()

  return minimal ? (
    <Button
      className='rounded-full w-auto'
      disabled={isAddingToCart}
      onClick={async () => {
        setIsAddingToCart(true)
        try {
          await addItem(item, 1)
          toast.success(t('Product.Added to Cart'), {
            action: {
              label: t('Product.Go to Cart'),
              onClick: () => router.push('/cart'),
            },
          })
        } catch (error: any) {
          toast.error(error.message)
        } finally {
          setIsAddingToCart(false)
        }
      }}
    >
      {isAddingToCart ? (
        <Spinner size="sm" />
      ) : (
        t('Product.Add to Cart')
      )}
    </Button>
  ) : (
    <div className='w-full space-y-2'>
      <Select
        value={quantity.toString()}
        onValueChange={(i) => setQuantity(Number(i))}
      >
        <SelectTrigger className=''>
          <SelectValue>
            {t('Product.Quantity')}: {quantity}
          </SelectValue>
        </SelectTrigger>
        <SelectContent position='popper'>
          {Array.from({ length: item.countInStock }).map((_, i) => (
            <SelectItem key={i + 1} value={`${i + 1}`}>
              {i + 1}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Button
        className='rounded-full w-full'
        type='button'
        disabled={isAddingToCart || isBuyingNow}
        onClick={async () => {
          setIsAddingToCart(true)
          try {
            const itemId = await addItem(item, quantity)
            toast.success(`Added ${quantity} item${quantity > 1 ? 's' : ''} to cart`)
            router.push(`/cart/${itemId}`)
          } catch (error: any) {
            toast.error(error.message)
          } finally {
            setIsAddingToCart(false)
          }
        }}
      >
        {isAddingToCart ? (
          <Spinner size="sm" />
        ) : (
          t('Product.Add to Cart')
        )}
      </Button>
      <Button
        variant='secondary'
        disabled={isAddingToCart || isBuyingNow}
        onClick={async () => {
          setIsBuyingNow(true)
          try {
            await addItem(item, quantity)
            toast.success('Item added! Redirecting to checkout...')
            router.push(`/checkout`)
          } catch (error: any) {
            toast.error(error.message)
          } finally {
            setIsBuyingNow(false)
          }
        }}
        className='w-full rounded-full '
      >
        {isBuyingNow ? (
          <Spinner size="sm" />
        ) : (
          t('Product.Buy Now')
        )}
      </Button>
    </div>
  )
}